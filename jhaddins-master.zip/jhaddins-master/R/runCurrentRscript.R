#' runCurrentRscript
#'
#' @description Intended to be used as an RStudio addin. A wrapper around
#'   \code{\link{system2}} to run Rscript with default arguments for easy
#'   use as an addin.
#'
#' @param path \code{character(1)}, a string specifying the path of the
#'   file to be used as the first Rscript command line argument (ideally
#'   a path to an R script).
#' @param command \code{character(1)}, to be executed, defaults to
#'   \code{"Rscript"}, which is the intended use.
#' @param outputFile \code{character(1)}, a string specifying the name of
#'   the file into which the output and errors produced by running the
#'   \code{command} will be redirected.
#' @param autoOpen \code{logical(1)}, if \code{TRUE} the \code{outputFile}
#'   will be automatically opened in RStudio.
#' @param addRhome \code{logical(1)}, if \code{TRUE} \code{R.home("bin")}
#'  will be added as a prefix to \code{command}. Useful if path to R is
#'  not added to the \code{"PATH"} environment variable.
#'
#' @importFrom rstudioapi getActiveDocumentContext navigateToFile
#'
#' @seealso \code{\link{system2}}
#'
#' @return Side-effects caused by addin execution.
runCurrentRscript <- function(
  path = path.expand(rstudioapi::getActiveDocumentContext()[["path"]]),
  command = "Rscript",
  outputFile = tempfile(),
  autoOpen = TRUE,
  addRhome = TRUE
) {
  if (isTRUE(addRhome)) {
    command <- file.path(R.home("bin"), command)
  }
  system2(
    command,
    args = c(path, "--vanilla"),
    stdout = outputFile,
    stderr = outputFile
  )
  if (!is.null(outputFile) && file.exists(outputFile) && isTRUE(autoOpen)) {
    rstudioapi::navigateToFile(outputFile)
  }
}
