#' Make light-weight highchart code
#'
#' @description Create JavaScript and html code for a \code{highchart}
#'   object in an html document such as a rendered R Markdown file
#'   with minimum bloat.
#'
#' @note The necessary JavaScript resources (e.g. highcharts.js, jquery.js)
#'   need to be available to the resulting html document for the
#'   highcharts to successfully render.
#'
#' @details
#' Uses \code{jsonlite::toJSON} to export the JavaScript.
#'
#' Optionally the output can be \code{cat}ed directly which is useful
#'   with \code{results='asis'} R Markdown chunk option - this will make
#'   the chart directly visible in the rendered html.
#'
#' @param hc \code{highchart}, object produced by the \code{highcharter}
#'   package functionality.
#' @param exportpath \code{character(1)} or \code{NULL}, if we want to export
#'   the created output to a file, specify the path here, keep \code{NULL}
#'   (default) to write nothing to a file. Potentially useful if one wants
#'   to keep the exported objects in a separate html file that are
#'   included separately.
#' @param adddiv \code{logical(1)}, if \code{TRUE} (default), adds the
#'   \code{<div>} tag to the bottom of the JavaScript This actually shows
#'   the chart.
#' @param wrapscript \code{logical(1)}, if \code{TRUE} (default), wraps
#'   the JavaScript in a \code{<script>} tag.
#' @param chartname \code{character(1)}, name of the chart, used as id
#'   instead of the default \code{"container"}.
#' @param docat \code{logical(1)}, if \code{TRUE}, uses \code{cat} to
#'   output the result. Useful if used in a R Markdown context with
#'   \code{results='asis'} chunk option, which makes it such the chart
#'   actually appears in the rendered result.
#'
#' @export
#'
#' @return \code{character()}, invisibly. The highchart defining JavaScript
#'   and html, one vector element per output row. Optionally side-effects.
#'
#' @examples
#' \dontrun{
#' # Needs the highcharter package installed to run
#' makeHighChart(highcharter::hc_add_series(
#'   highcharter::highchart(),
#'   data = datasets::mtcars$mpg
#' ))}
#'
#' \dontrun{
#' # Needs the highcharter package installed to run
#' # Example Rmd chunk to get a highchart in output:
#' ```{r results='asis'}
#' library(highcharter)
#' library(jhaddins)
#' hc <- hc_add_series(highchart(), data = datasets::mtcars$mpg)
#' makeHighChart(hc, chartname = "dummychart", docat = TRUE)
#' ```}
makeHighChart <- function(
  hc,
  exportpath = NULL,
  adddiv = TRUE,
  wrapscript = TRUE,
  chartname = "container",
  docat = FALSE
){

  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    message("Package jsonlite needed.")
    return()
  }

  # Produce the js from the object --------------------------------------------
  # Replicating highcharter::export_hc with base and jsonlite
  cChart <- jsonlite::toJSON(
    hc$x$hc_opts,
    pretty = TRUE, auto_unbox = TRUE, force = TRUE, null = "null"
  )
  cChart <- unlist(strsplit(cChart, "\n")[1])
  cChart <- gsub('"NA"', 'null', cChart, fixed = TRUE)
  cChart <- gsub("'NA'", 'null', cChart, fixed = TRUE)
  cChart <- sub("\"", "", cChart)
  cChart <- sub("\":", ":", cChart)
  cChart <- paste(unlist(cChart)[-1], "    ", collapse = "\n")
  cChart <- gsub("\n\\s{4,}\\]\\,\n\\s{4,}\\[\n\\s{4,}", "],[", cChart)
  cChart <- paste0(
    "$(function () {\n  $('#container').highcharts({\n",
    cChart,
    "\n  );\n});"
  )

  # Wrap into (optional) niceties ---------------------------------------------
  cChart <- gsub(
    "$('#container')",
    sprintf("$('#%s')", chartname),
    cChart,
    fixed = TRUE
  )
  if (isTRUE(wrapscript)) {
    cChart <- c('<script type="text/javascript">', cChart, '</script>')
  }
  if (isTRUE(adddiv)) {
    divtext <- sprintf('<div id="%s"></div>', chartname)
    cChart <- c(cChart, "", divtext)
  }

  # If desired, produce optional side effects ---------------------------------
  if (!is.null(exportpath)) {
    writeLines(cChart, exportpath)
  }
  if (isTRUE(docat)) {
    cat(paste(cChart, collapse = "\n"))
  }

  invisible(cChart)
}
