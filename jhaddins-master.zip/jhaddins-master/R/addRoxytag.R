#' roxyfy
#'
#' @description Encloses \code{str} into \code{\\tag{}}.
#'
#' @param str \code{character(1)}, string to enclose.
#' @param tag \code{character(1)}, to enclose \code{str} with.
#' @param splitLines \code{logical(1)}, if \code{TRUE},
#'   splits \code{str} by \code{\\n} and applies the tag
#'   to each element.
#'
#' @return \code{character(1)}, the input \code{str} enclosed
#'   into the provided \code{tag}.
#'
#' @examples \dontrun{roxyfy("character", "code")}
roxyfy <- function(str, tag = NULL, splitLines = TRUE) {
  if (is.null(tag)) {
    return(str)
  }
  if (!isTRUE(splitLines)) {
    return(paste0("\\", tag, "{", str, "}"))
  }
  str <- unlist(strsplit(str, "\n"))
  str <- paste0("\\", tag, "{", str, "}")
  paste(str, collapse = "\n")
}

#' addRoxytag
#'
#' @description Intended to be used as an RStudio addin. When
#'   executed, adds a tag around the selections in the active
#'   RStudio document using \code{\link{roxyfy}}. See the
#'   wrappers \code{\link{addRoxytagCode}},
#'   \code{\link{addRoxytagLink}}, \code{\link{addRoxytagEqn}}
#'   for examples.
#'
#' @param tag \code{character(1)}, roxygen tag to use.
#'
#' @importFrom rstudioapi getActiveDocumentContext modifyRange
#'
#' @seealso \code{\link{roxyfy}}, \code{\link{addRoxytagCode}},
#'   \code{\link{addRoxytagLink}}, \code{\link{addRoxytagEqn}}
#'
#' @return Side-effects caused by addin execution.
addRoxytag <- function(tag = NULL) { # nocov start
  context <- rstudioapi::getActiveDocumentContext()
  lapply(X = context[["selection"]]
       , FUN = function(thisSel, contextid) {
           rstudioapi::modifyRange(location = thisSel[["range"]]
                                 , roxyfy(thisSel[["text"]], tag)
                                 , id = contextid)
         }
       , contextid = context[["id"]]
       )
  return(invisible(NULL))
} # nocov end

#' addRoxytagCode
#'
#' @description Intended to be used as an RStudio addin. When
#'   executed, adds a tag \code{"code{}"} around the selections
#'   in the active RStudio document
#'
#' @seealso \code{\link{addRoxytag}}
addRoxytagCode <- function() {  # nocov start
  addRoxytag(tag = "code")
} # nocov end

#' addRoxytagLink
#'
#' @description Intended to be used as an RStudio addin. When
#'   executed, adds a tag \code{"link{}"} around the selections
#'   in the active RStudio document
#'
#' @seealso \code{\link{addRoxytag}}
addRoxytagLink <- function() { # nocov start
  addRoxytag(tag = "link")
} # nocov end

#' addRoxytagEqn
#'
#' @description Intended to be used as an RStudio addin. When
#'   executed, adds a tag \code{"eqn{}"} around the selections
#'   in the active RStudio document
#'
#' @seealso \code{\link{addRoxytag}}
addRoxytagEqn <- function() { # nocov start
  addRoxytag(tag = "eqn")
} # nocov end
