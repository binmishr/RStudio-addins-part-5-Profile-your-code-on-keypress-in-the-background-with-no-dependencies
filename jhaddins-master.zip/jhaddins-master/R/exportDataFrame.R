#' exportDataFrame
#'
#' @description Intended to be used as an RStudio addin. When in an
#'   RStudio document (or console), select a name of a data.frame
#'   (such as `mtcars`) and execute the addin. The content of the
#'   data frame will be pasted into a temporary tab separated text
#'   file, opened in RStudio and its content selected. Now it can
#'   be copied and pasted into other places on the client machine
#'   from RStudio Server.
#'
#' @details This is useful in an RStudio Server setting, where the IDE
#'   running on a server exposed via a browser does not have access
#'   to the clipboard of the client machine.
#'
#' @importFrom utils write.table
#' @importFrom rstudioapi navigateToFile getSourceEditorContext
#' @importFrom rstudioapi getActiveDocumentContext setSelectionRanges
#'
#' @return Side-effects caused by addin execution.
exportDataFrame <- function() { # nocov start
  context <- rstudioapi::getActiveDocumentContext()
  dt <- getFromSysframes(context[["selection"]][[1]][["text"]])
  tmpF <- tempfile()
  write.table(dt, file = tmpF, sep = "\t")
  rstudioapi::navigateToFile(tmpF)
  x <- rstudioapi::getSourceEditorContext()
  while (!(grepl(tmpF, x$path, fixed = TRUE))) {
    Sys.sleep(0.2)
    x <- rstudioapi::getSourceEditorContext()
  }
  rng <- structure(
    list(
      start = structure(c(row = 1, column = 1), class = "document_position"),
      end = structure(c(row = Inf, column = Inf), class = "document_position")
    ),
    class = "document_range"
  )
  rstudioapi::setSelectionRanges(rng, id = x$id)
} # nocov end
