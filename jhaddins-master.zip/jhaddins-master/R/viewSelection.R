#' View object selected in RStudio
#'
#' @description Intended to be used as an RStudio addin.
#'   Tries to view the selections in RStudio active document
#'   in a meaningful way using \code{\link{getViewArgs}}.
#'
#' @param ctx \code{list}, context of document selection objects,
#'   usually provided by \code{\link{getActiveDocumentContext}}.
#'
#' @importFrom rstudioapi getActiveDocumentContext navigateToFile
#' @importFrom utils capture.output str
#'
#' @seealso \code{\link{getViewArgs}}
#'
#' @return \code{list of NULL}, invisibly and side-effects caused by
#'   addin execution.
viewSelection <- function(
  ctx = rstudioapi::getActiveDocumentContext()
) { # nocov start
  invisible(lapply(
    X = ctx[["selection"]],
    FUN = function(thisSel) {
      callArgs <- getViewArgs(thisSel[["text"]])
      do.call(what = callArgs[["what"]], args = callArgs[["args"]])
    }
  ))
} # nocov end

#' Get object value from sys frames
#'
#' @description Looks for \code{x} in all \code{sys.frames} (except
#'   the current one) and returns the value if found, \code{NULL}
#'   otherwise.
#'
#' @param x \code{character(1)} string, name of the object to look for.
#'
#' @seealso
#'   \code{\link{sys.frames}}
#'   \code{\link{sys.nframe}}
#'
#' @examples \dontrun{
#'   getFromSysframes("reshape")
#' }
#'
#' @return \code{NULL} if object with name \code{x} not found, value of
#'   the object with name \code{x} if found, invisibly.
getFromSysframes <- function(x) {
  if (!(is.character(x) && length(x) == 1 && nchar(x) > 0)) {
    warning("Expecting a non-empty character of length 1. Returning NULL.")
    return(invisible(NULL))
  }
  validframes <- c(rev(sys.frames()[-sys.nframe()]), .GlobalEnv)
  res <- NULL
  for (i in validframes) {
    inherits <- identical(i, .GlobalEnv)
    res <- get0(x, i, inherits = inherits)
    if (!is.null(res)) {
      return(res)
    }
  }
  return(invisible(res))
}

#' Get view arguments
#'
#' @description Retrieves a function and its arguments to be used to
#'   view the object defined by \code{chr} with
#'   \code{\link{viewSelection}}.
#'
#' @param chr \code{character(1)} string to process.
#' @param tryEval \code{logical(1)} if \code{TRUE}, tries retrieving
#'   the value of \code{chr} by parsing it and using \code{eval}.
#'
#' @examples \dontrun{
#'   x <- datasets::anscombe; y <- getViewArgs("x")
#'   print(getViewArgs("reshape"))
#' }
#'
#' @seealso
#'   \code{\link{getFromSysframes}}
#'   \code{\link{viewSelection}}
#'
#' @return \code{list} with elements \code{what} and \code{args} to use for
#'   \code{do.call} in \code{\link{viewSelection}}
getViewArgs <- function(
  chr,
  tryEval = getOption("jhaddins_view_tryeval", default = TRUE)
) {
  blankCall <- invisible(
    list(what = function(...) invisible(NULL), args = list())
  )
  if (!(is.character(chr) && length(chr) == 1 && nchar(chr) > 0)) {
    message("Invalid input, expecting a non-empty character of length 1")
    return(blankCall)
  }

  # maybe it is an unquoted filename - if so, open it -------------------
  if (file.exists(chr)) {
    return(invisible(
      list(what = rstudioapi::navigateToFile
         , args = list(chr))
    ))
  }

  # or maybe it is a quoted filename - if so, open it -------------------
  if (file.exists(gsub("\"", "", chr, fixed = TRUE))) {
    return(invisible(
      list(what = rstudioapi::navigateToFile
         , args = list(gsub("\"", "", chr, fixed = TRUE))
         )
      ))
  }

  # try to get the objec, see if found, try simplest eval ---------------
  obj <- getFromSysframes(chr)
  if (is.null(obj)) {
    if (isTRUE(tryEval)) {
      try(obj <- eval(parse(text = chr)), silent = TRUE)
    }
    if (is.null(obj)) {
      message(sprintf("Object %s not found", chr))
      return(blankCall)
    }
  }

  # guess if we can use the viewer --------------------------------------
  candf <- !inherits(try(as.data.frame(obj), silent = TRUE), "try-error")
  if (is.list(obj) || candf || is.function(obj)) {
    return(invisible(
      list(what = "View"
         , args = list(x = obj, title = chr))
      ))
  } else {
  # if not, view the structure ------------------------------------------
    return(invisible(
      list(what = "View"
         , args = list(x = capture.output(str(obj)), title = chr))
    ))
  }
}
